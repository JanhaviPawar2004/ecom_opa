package com.example.Order_service;

import org.springframework.stereotype.Service;
import java.time.LocalDateTime;
import java.util.List;

@Service
public class OrderService {

    private final OrderRepository repository;

    public OrderService(OrderRepository repository){
        this.repository = repository;
    }

    public Order placeOrder(Order order){

        order.setStatus(OrderStatus.PLACED);
        order.setOrderDate(LocalDateTime.now());

        return repository.save(order);
    }

    public List<Order> getUserOrders(Long userId){
        return repository.findByUserId(userId);
    }

    public List<Order> getAllOrders(){
        return repository.findAll();
    }

    public Order updateStatus(Long id, OrderStatus status){

        Order order = repository.findById(id)
                .orElseThrow(() -> new RuntimeException("Order not found"));

        order.setStatus(status);

        return repository.save(order);
    }

    public void cancelOrder(Long id){

        Order order = repository.findById(id)
                .orElseThrow(() -> new RuntimeException("Order not found"));

        order.setStatus(OrderStatus.CANCELLED);

        repository.save(order);
    }
}