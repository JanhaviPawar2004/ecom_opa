package com.example.Order_service;

import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/orders")
public class OrderController {

    private final OrderService service;

    public OrderController(OrderService service){
        this.service = service;
    }

    @PostMapping
    public Order placeOrder(@RequestBody Order order){
        return service.placeOrder(order);
    }

    @GetMapping("/user/{userId}")
    public List<Order> getUserOrders(@PathVariable Long userId){
        return service.getUserOrders(userId);
    }

    @GetMapping
    public List<Order> getAllOrders(){
        return service.getAllOrders();
    }

    @PutMapping("/{id}/status")
    public Order updateStatus(@PathVariable Long id,
                              @RequestParam OrderStatus status){
        return service.updateStatus(id,status);
    }

    @DeleteMapping("/{id}")
    public void cancelOrder(@PathVariable Long id){
        service.cancelOrder(id);
    }
}