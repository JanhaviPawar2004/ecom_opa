package com.example.Order_service;

public enum OrderStatus {

    PLACED,
    SHIPPED,
    DELIVERED,
    CANCELLED

}