package com.example.User_service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserService {

    private final UserRepository repository;

    @Autowired
    public UserService(UserRepository repository) {
        this.repository = repository;
    }

    // Register user
    public User save(User user) {

        if(repository.findByUsername(user.getUsername()).isPresent()){
            throw new RuntimeException("Username already exists");
        }

//        user.setRole("USER");
        user.setStatus("ACTIVE");

        return repository.save(user);
    }
    
    // Find user by username
    public User findByUsername(String username){
        return repository.findByUsername(username).orElse(null);
    }


    // Get all users
    public List<User> getAll() {
        return repository.findAll();
    }

    // Get a user by ID
    public User getById(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new RuntimeException("User not found with id: " + id));
    }

    // Update user by ID
    public User update(Long id, User u) {
        User existing = repository.findById(id)
                .orElseThrow(() -> new RuntimeException("User not found with id: " + id));

        if(u.getName()!=null)
        {
        existing.setName(u.getName());
        }
        if(u.getAddress()!=null)
        {
        existing.setAddress(u.getAddress());
        }

        return repository.save(existing);
    }

    // Soft delete user (mark as inactive)
    public User delete(Long id) {
        User existing = repository.findById(id)
                .orElseThrow(() -> new RuntimeException("User not found with id: " + id));

        existing.setStatus("Inactive");
        return repository.save(existing);
    }
}
