package com.example.User_service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/users")
public class UserController {

    private final UserService service;

    @Autowired
    public UserController(UserService service) {
        this.service = service;
    }

    // Register API
    @PostMapping("/register")
    public User register(@RequestBody User user) {
        return service.save(user);
    }

    // Login API
    @PostMapping("/login")
    public Map<String,String> login(@RequestParam String username,
                                    @RequestParam String password) {

        User user = service.findByUsername(username);

        if(user == null || !user.getPassword().equals(password)){
            throw new RuntimeException("Invalid Credentials");
        }

        if(user.getStatus().equals("Inactive")){
            throw new RuntimeException("Account disabled");
        }

        String token = JwtUtil.generateToken(user.getUsername(), user.getRole());

        Map<String,String> response = new HashMap<>();
        response.put("token", token);
        response.put("role", user.getRole());

        return response;
    }

    // Get all users
    @GetMapping
    public List<User> getAll() {
        return service.getAll();
    }

    // Get user by ID
    @GetMapping("/{id}")
    public User getById(@PathVariable Long id) {
        return service.getById(id);
    }

    // Update user
    @PutMapping("/{id}")
    public User update(@PathVariable Long id, @RequestBody User user) {
        return service.update(id, user);
    }

    // Delete user
    @DeleteMapping("/{id}")
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}