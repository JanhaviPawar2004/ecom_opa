package com.example.Payment_service;

import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/payment")
public class PaymentController {

    private final PaymentService service;

    public PaymentController(PaymentService service){
        this.service = service;
    }

    @PostMapping("/create")
    public Map<String,String> createPayment(@RequestParam Long orderId,
                                            @RequestParam double amount) throws Exception {

        String url = service.createPaymentSession(orderId, amount);

        Map<String,String> response = new HashMap<>();
        response.put("checkoutUrl",url);

        return response;
    }

    @GetMapping("/success")
    public String success(){
        return "Payment Successful";
    }

    @GetMapping("/cancel")
    public String cancel(){
        return "Payment Cancelled";
    }
}
